package com.example.billiardaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat

/**
 * Foreground service (type mediaProjection):
 *  - hiện thông báo bắt buộc
 *  - tạo overlay trong suốt không chặn cảm ứng
 *  - bật ScreenCapturer trên luồng nền
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.billiardaim.START"
        const val ACTION_STOP = "com.example.billiardaim.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "capture"
        private const val NOTIF_ID = 1
    }

    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private var overlay: OverlayView? = null
    private lateinit var windowManager: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        // Android 14+: phải gọi startForeground (đúng type) TRƯỚC getMediaProjection.
        startAsForeground()

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null) { shutdown(); return }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addOverlay()
        startCapture()
    }

    private fun addOverlay() {
        val view = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Giai đoạn 1: không nhận cảm ứng để không cản thao tác bên dưới.
            // Giai đoạn 3 sẽ bỏ NOT_TOUCHABLE khi cần kéo chọn hướng ngắm.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(view, lp)
        overlay = view
    }

    @Suppress("DEPRECATION")
    private fun startCapture() {
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        // Thiết kế cho 1980x890 @ 360dpi, nhưng lấy kích thước thật để chạy đúng trên mọi máy.
        capturer = ScreenCapturer(
            this, projection!!,
            metrics.widthPixels, metrics.heightPixels, metrics.densityDpi
        ) { frame ->
            // Giai đoạn 2: đưa `frame` vào TableDetector + BallDetector tại đây.
            // Giai đoạn 3: tính phản xạ rồi gọi overlay?.setAimPath(...).
            frame.recycle()
        }.also { it.start() }
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW
            )
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun shutdown() {
        capturer?.stop(); capturer = null
        overlay?.let { runCatching { windowManager.removeView(it) } }; overlay = null
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
